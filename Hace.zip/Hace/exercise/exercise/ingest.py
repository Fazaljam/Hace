import duckdb
import numpy as np
import pandas as pd
conn = duckdb.connect('warehouse.db')

##CREATE SCHEMA 'BLOG_ANALYSIS'
df = conn.execute("""
create or replace schema blog_analysis
"""
)

#CREATE TABLE 'VOTES'
CREATE_TABLE_votes = """
        CREATE or REPLACE TABLE votes (
            Id integer,
            PostId integer,
            VoteTypeId integer,
            CreationDate varchar,
            UserId integer null,
            BountyAmount integer null,
    );
"""

## INSERT DATA INTO TABLE VOTES
conn.execute("""INSERT INTO votes SELECT * FROM read_json_auto('uncommitted/votes.jsonl');
""")

##QUERY TO EXEUTE THE TABLE
conn.execute("""select * from votes;
""")
cursor = conn.cursor()
conn.table('votes').show()

try:
    cursor.execute(CREATE_TABLE_votes)
    print('Table created')
except Exception as e:
    print('Table not created')
    conn.close()






