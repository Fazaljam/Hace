import duckdb
import numpy as np
import pandas as pd
conn = duckdb.connect('warehouse.db')
df = conn.execute("""
Select * from read_json_auto('uncommitted/votes.jsonl')
limit 10
"""

).df()

#df =df.drop(['UserId','BountyAmount'], axis=1)
print(df)


