import duckdb

conn = duckdb.connect('warehouse.db')

df1 = conn.execute("""
CREATE or REPLACE VIEW outlier_weeks (Year, WeekNumber, VoteCount)
"""
)


